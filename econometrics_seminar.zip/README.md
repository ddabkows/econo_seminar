Authors:  Bozet Baptiste
	  Dabkowski Dominik
	  Kivrak Selin
	  Petitjean Flavio

This folder contains all the files that are needed for the analysis.


[.git]
This folder is not important, it contains all the version control files.

[img]
This folder contains the png's of the RDD regressions.

[report]
This folder contains the pdf report with all our contributions.

[src]
This folder contains all the source codes needed to perform our analysis.

[data]
This folder contains all the data files needed by the source code, please do not move anything you find
in there.

